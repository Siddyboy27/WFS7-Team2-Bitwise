
import userLayer.UserUI;

public class MainApp {
    public static void main(String[] args) {
        UserUI userUI = new UserUI();
        userUI.getInterface();
    }
}
