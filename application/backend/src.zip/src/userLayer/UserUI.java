package userLayer;

public class UserUI {
    public void getInterface() {
        System.out.println("User Interface");
    }
}
