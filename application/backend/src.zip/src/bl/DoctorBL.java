package bl;


import dao.impl.DoctorDAOImpl;
import dao.intf.DoctorDAOIntf;
import models.Doctor;
import java.util.List;

public class DoctorBL {
    private final DoctorDAOIntf doctorDAOIntf = new DoctorDAOImpl();

    public void addDoctor(Doctor doctor) {
        doctorDAOIntf.addDoctor(doctor);
    }

    public void updateDoctor(Doctor doctor) {
        doctorDAOIntf.updateDoctor(doctor);
    }

    public void deleteDoctor(int doctorID) {
        doctorDAOIntf.deleteDoctor(doctorID);
    }

    public Doctor getDoctorById(int doctorID) {
        return doctorDAOIntf.getDoctorById(doctorID);
    }

    public List<Doctor> getAllDoctors() {
        return doctorDAOIntf.getAllDoctors();
    }
}
