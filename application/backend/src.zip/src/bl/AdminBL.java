package bl;

public class AdminBL {

}
