package models;

import java.util.Arrays;

public class Medication {
    //list of products(array of objects Product) with order ID and quantity with a total price
    private int id;
    private Prescription[] products;
    private int quantity;
    private double totalPrice;
    private String doctorName;
    private String description;
    private String type;
    private Patient patient;

    public Medication(int id, Prescription[] products, int quantity, double totalPrice, String doctorName, String description, Patient patient) {
        this.id = id;
        this.products = products;
        this.quantity = quantity;
        this.totalPrice = calculateTotalPrice();
        this.doctorName = doctorName;
        this.description = description;
        this.patient = patient;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public Prescription[] getProducts() {
        return products;
    }

    public int getQuantity() {
        return quantity;
    }

    public double calculateTotalPrice(){
        double total = 0;
        for (Prescription product : products) {
            total += product.getPrice();
        }
        return total;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setProducts(Prescription[] products) {
        this.products = products;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    @Override
    public String toString() {
        return "Medication{" +
                "id=" + id +
                ", products=" + Arrays.toString(products) +
                ", quantity=" + quantity +
                ", totalPrice=" + totalPrice +
                ", doctorName='" + doctorName + '\'' +
                ", patient='" + patient + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}