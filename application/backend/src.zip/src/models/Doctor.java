package src.models;
import java.util.ArrayList;
import java.util.List;

public class Doctor extends User{
    private int doctorID;
    private String specialization;
    private String experience;
    private double rating;
    private final boolean isDoctor = true;
    private List<Boolean> isAvailable = new ArrayList<>(3);
    private List<Appointment> appointments;



    public Doctor(int id, int doctorID, String name, String email, String password, String address, String phoneNumber, String specialization, String experience, double rating) {
        super(id, name, email, password, address, phoneNumber);
        this.doctorID = doctorID;
        this.specialization = specialization;
        this.experience = experience;
        this.rating = rating;
        appointments = new ArrayList<>();
    }

    //GETTERS AND SETTERS FOR ALL
    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    //update availability
    public void setAvailable(int day, boolean availability){
        isAvailable[day] = availability;
    }

    public boolean getAvailable(int day){
        return isAvailable[day];
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }

    public void clearAllAppointments(){
        appointments.clear();
    }

    //TO STRING
    @Override
    public String toString() {
        return "Doctor{" +
                "id=" + getDoctorID() +
                ", name='" + getName() + '\'' +
                ", email='" + getEmail() + '\'' +
                // ", password='" + getPassword() + '\'' +
                ", address='" + getAddress() + '\'' +
                ", phoneNumber='" + getPhoneNumber() + '\'' +
                ", specialization='" + specialization + '\'' +
                ", experience='" + experience + '\'' +
                ", rating=" + rating +
                '}';
    }

    public boolean isDoctor() {
        return isDoctor;
    }

    public void setDoctor(boolean doctor) {
        isDoctor = doctor;
    }

    //EQUALS METHOD

    //HASH CODE: BASED ON SPECIALIZATION
    @Override
    public int hashCode() {
        return specialization != null ? specialization.hashCode() : 0;
    }
}
