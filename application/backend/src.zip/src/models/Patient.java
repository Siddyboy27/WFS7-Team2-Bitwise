package src.models;


import java.util.ArrayList;
import java.util.List;

public class Patient {
    private int id;
    private String name;
    private String email;
    private String address;
    private String gender;
    private String phoneNumber;
    private List<Prescription> prescriptions;
    
    public Patient(String name, String email, String address, String gender, String phoneNumber) {
        this.name = name;
        this.email = email;
        this.address = address;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
        prescriptions = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getGender() {
        return this.gender;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public List<Prescription> getAllPrescriptions() {
        return prescriptions;
    }

    public void addPrescription(Prescription prescription) {
        prescriptions.add(prescription);
    }

    public void removePrescription(Prescription prescription) {
        prescriptions.remove(prescription);
    }

    //TO STRING
    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                // ", password='" + password + '\'' +
                ", address='" + address + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }
    
    //EQUALS
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Patient)) return false;
        Patient customer = (Patient) o;
        return getId() == customer.getId() &&
                getName().equals(customer.getName()) &&
                getEmail().equals(customer.getEmail()) &&
                getPassword().equals(customer.getPassword()) &&
                getAddress().equals(customer.getAddress()) &&
                getPhoneNumber().equals(customer.getPhoneNumber());
    }

    
    // //COMPARE TO
    // public int compareTo(Patient p) {
    //     return this.getName().compareTo(p.getName());

}
