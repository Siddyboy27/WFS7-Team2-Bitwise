package src.models;
import java.util.HashMap;

public class Appointment {
    //hashmap of time and boolean of three days
    //store last updated date
    HashMap<Integer, Boolean> timeSlots;
    private int startTime;
    private int endTime;

    Appointment() {
        timeSlots = new HashMap<>();
        for (int i = startTime; i < endTime; i++) {
            timeSlots.put(i, true);
        }
    }

    public HashMap<Integer, Boolean> getTimeSlots() {
        return timeSlots;
    }

    public void setTimeSlots(HashMap<Integer, Boolean> timeSlots) {
        this.timeSlots = timeSlots;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public void addTimeSlot(int time) {
        timeSlots.put(time, true);
    }

    public void removeTimeSlot(int time) {
        timeSlots.put(time, false);
    }

    public boolean isAvailable(int time) {
        return timeSlots.get(time);
    }

    public void updateAvailabilityByTime(int time, boolean availability) {
        timeSlots.put(time, availability);
    }

    public void updateAvailability(int startTime, int endTime, boolean availability) {
        for (int i = startTime; i < endTime; i++) {
            timeSlots.put(i, availability);
        }
    }

    public void updateAllAvailability(HashMap<Integer, Boolean> availability) {
        timeSlots = availability;
    }
    
    @Override
    public String toString() {
        return "Appointment{" +
                "timeSlots=" + timeSlots +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                '}';
    }

}
