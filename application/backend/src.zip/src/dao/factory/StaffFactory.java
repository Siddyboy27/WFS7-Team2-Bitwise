package dao.factory;

public class StaffFactory {
    //staff factory class to select type of implementation
    public static StaffFactory getStaffFactory(String type) {
        if (type.equalsIgnoreCase("impl")) {
            return new StaffDAOImpl();
        }
        return null;
    }
}
