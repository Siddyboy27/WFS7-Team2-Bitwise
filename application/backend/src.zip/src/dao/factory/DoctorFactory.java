package dao.factory;

import dao.impl.DoctorJDBCImpl;

public class DoctorFactory {
    //doctor factory class to select type of implementation
    public static DoctorFactory getDoctorFactory(String type) {
        if (type.equalsIgnoreCase("impl")) {
            return new DoctorDAOImpl();
        }
        return null;
    }
}
