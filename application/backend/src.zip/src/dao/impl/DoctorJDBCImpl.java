package dao.impl;

public class DoctorJDBCImpl {
    //doctor jdbc implementation
    //add doctor
    //update doctor
    //delete doctor
    //get doctor by id
    //get all doctors
}
