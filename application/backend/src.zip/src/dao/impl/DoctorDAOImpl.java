package dao.impl;
import dao.intf.DoctorDAOIntf;
import models.Doctor;
import java.util.ArrayList;
import java.util.List;
public class DoctorDAOImpl implements DoctorDAOIntf {
    private final List<Doctor> doctors = new ArrayList<>();

    @Override
    public void addDoctor(Doctor doctor) {
        doctors.add(doctor);
    }

    @Override
    public void updateDoctor(Doctor doctor) {
        for (Doctor d : doctors) {
            if (d.getDoctorID() == doctor.getDoctorID()) {
                d.setSpecialization(doctor.getSpecialization());
                d.setExperience(doctor.getExperience());
                d.setRating(doctor.getRating());
            }
        }
    }

    @Override
    public void deleteDoctor(int doctorID) {
        doctors.removeIf(doctor -> doctor.getDoctorID() == doctorID);
    }

    @Override
    public Doctor getDoctorById(int doctorID) {
        return doctors.stream()
                .filter(doctor -> doctor.getDoctorID() == doctorID)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Doctor> getAllDoctors() {
        return new ArrayList<>(doctors);
    }
}
