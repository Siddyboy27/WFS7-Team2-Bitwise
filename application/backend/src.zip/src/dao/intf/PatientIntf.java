package dao.intf;

import java.util.List;
import src.model.Appointment;
import src.model.Prescription;

public interface PatientIntf {
    void registerPatient();
    void updatePatient();
   
    List<Appointment> viewAllAppointments();
    void bookAppointment(int time, int doctorId);
    void cancelAppointment(int time, int doctorId);

    
    List<Prescription> viewAllPrescriptions();
    void addPrescription(Prescription prescription);
    void updatePrescription(int prescriptionId);
    void deletePrescription(int prescriptionId);
}
