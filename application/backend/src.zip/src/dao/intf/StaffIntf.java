package dao.intf;


// public interface StaffIntf {
//     void registerPatient();
//     void bookAppointment();
// }

