package dao.intf;

public interface DoctorIntf {
    void registerDoctor();
    void updateDoctor();
    void deleteDoctor();
    void viewDoctor();

    void viewAllDoctors();

    void viewAppointments();
    void viewAllAppointments();
    void addAppointment();
    void updateAppointment();
    void deleteAppointment();

    void viewPrescriptions();
    void viewAllPrescriptions();
    void addPrescription();
    void updatePrescription();
    void deletePrescription();
}