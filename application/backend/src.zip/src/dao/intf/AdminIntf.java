package dao.intf;

// public interface AdminIntf {
//     void manageDoctors();
//     void generateReports();
// }
