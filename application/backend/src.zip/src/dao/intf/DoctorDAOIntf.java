package dao.intf;

import models.Doctor;
import java.util.List;

public interface DoctorDAOIntf {
    void addDoctor(Doctor doctor);
    void updateDoctor(Doctor doctor);
    void deleteDoctor(int doctorID);
    Doctor getDoctorById(int doctorID);
    List<Doctor> getAllDoctors();
}
